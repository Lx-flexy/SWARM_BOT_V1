"""
config.py — SWARM BOT configuration
--------------------------------------
All tunable parameters live here so you don't have to dig through logic code.
"""

import cv2

# ---------------- ESP32 connection ----------------
ESP32_IP = "192.168.29.68"          # <-- set this to your ESP32's IP from Serial Monitor
BASE_URL = f"http://{ESP32_IP}"
COMMAND_COOLDOWN = 0.25              # min seconds between sending the SAME command again
REQUEST_TIMEOUT = 0.4                # seconds to wait for ESP32 HTTP response

# ---------------- Camera ----------------
CAMERA_INDEX = 0
FRAME_WIDTH = 1280
FRAME_HEIGHT = 720

# ---------------- ArUco setup ----------------
ARUCO_DICT_NAME = cv2.aruco.DICT_4X4_50
BOT_MARKER_ID = 1
TARGET_MARKER_ID = 25

# ---------------- Navigation tuning ----------------
ANGLE_THRESHOLD_DEG = 15.0           # within +-15 deg of target -> go FORWARD

# Marker "apparent size" (avg side length in pixels) used as a simple distance proxy.
# Bigger marker on screen = robot is closer to it.
TARGET_REACHED_MARKER_SIZE = 140.0   # px; tune this based on your camera height/marker size

# ---------------- Safety ----------------
# If bot or target marker is not seen for this many consecutive frames, send STOP.
MAX_MISSING_FRAMES = 5
