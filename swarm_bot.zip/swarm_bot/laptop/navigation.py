"""
navigation.py — Navigation decision logic
----------------------------------------------
Given the bot's position/heading and the target's position/size,
decide whether to go FORWARD, LEFT, RIGHT, or STOP (target reached).
"""

import math
import config


def normalize_angle(angle):
    """Normalize an angle to the range -180..180 degrees."""
    while angle > 180:
        angle -= 360
    while angle < -180:
        angle += 360
    return angle


def target_direction_deg(bot_center, target_center):
    """Angle (deg, image coords) from bot center to target center."""
    dx = target_center[0] - bot_center[0]
    dy = target_center[1] - bot_center[1]
    return math.degrees(math.atan2(dy, dx))


def compute_angle_error(bot_heading_deg, target_angle_deg):
    """
    Positive error -> target is to the RIGHT of bot heading -> should turn RIGHT
    Negative error -> target is to the LEFT of bot heading -> should turn LEFT
    """
    error = target_angle_deg - bot_heading_deg
    return normalize_angle(error)


def decide_command(angle_error, target_marker_size):
    """
    Core navigation decision.
    Returns one of: "forward", "left", "right", "stop"
    """
    # Target reached check (based on apparent marker size = distance proxy)
    if target_marker_size >= config.TARGET_REACHED_MARKER_SIZE:
        return "stop"

    if angle_error > config.ANGLE_THRESHOLD_DEG:
        return "right"
    elif angle_error < -config.ANGLE_THRESHOLD_DEG:
        return "left"
    else:
        return "forward"
