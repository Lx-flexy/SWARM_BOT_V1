"""
main.py — SWARM BOT control loop (V1: one robot, one target)
------------------------------------------------------------------
Pipeline per frame:
    capture -> detect ArUco markers -> find BOT + TARGET
    -> compute position/orientation -> compute angle error
    -> decide command -> send to ESP32 -> draw UI -> repeat

Run:
    pip install opencv-contrib-python requests
    python main.py

Before running:
    1. Upload esp32/swarm_bot_esp32/swarm_bot_esp32.ino to the ESP32
    2. Note the IP printed in Serial Monitor, put it in config.py -> ESP32_IP
    3. Print your ArUco markers (DICT_4X4_50): ID 1 on the robot, ID 25 as target
"""

import cv2

import config
from aruco_detection import (
    create_detector,
    detect_markers,
    marker_center,
    marker_heading_deg,
    marker_size,
    draw_marker_info,
)
from navigation import target_direction_deg, compute_angle_error, decide_command
from communication import ESP32Link


def draw_ui(frame, bot_info, target_info, angle_error, command, status):
    h, w = frame.shape[:2]
    y = 30
    line_gap = 28

    def put(text, color=(255, 255, 255)):
        nonlocal y
        cv2.putText(frame, text, (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        y += line_gap

    put(f"BOT ID: {config.BOT_MARKER_ID}   TARGET ID: {config.TARGET_MARKER_ID}")

    if bot_info:
        put(f"BOT HEADING: {bot_info['heading']:.1f} deg")
    else:
        put("BOT NOT FOUND", (0, 0, 255))

    if target_info:
        put(f"TARGET SIZE: {target_info['size']:.1f} px")
    else:
        put("TARGET NOT FOUND", (0, 0, 255))

    if bot_info and target_info:
        put(f"ANGLE ERROR: {angle_error:+.1f} deg")

    cmd_color = (0, 255, 0) if command == "forward" else \
                (0, 165, 255) if command in ("left", "right") else (0, 0, 255)
    put(f"COMMAND: {command.upper()}", cmd_color)
    put(f"STATUS: {status}")

    # Draw line + heading arrow if both markers found
    if bot_info and target_info:
        bx, by = int(bot_info["center"][0]), int(bot_info["center"][1])
        tx, ty = int(target_info["center"][0]), int(target_info["center"][1])
        cv2.line(frame, (bx, by), (tx, ty), (255, 255, 0), 2)

        # heading arrow (30 px long) from bot center
        import math
        hd = math.radians(bot_info["heading"])
        hx = int(bx + 40 * math.cos(hd))
        hy = int(by + 40 * math.sin(hd))
        cv2.arrowedLine(frame, (bx, by), (hx, hy), (0, 255, 255), 3, tipLength=0.3)


def main():
    detector = create_detector()
    link = ESP32Link()

    cap = cv2.VideoCapture(config.CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)

    bot_missing_frames = 0
    target_missing_frames = 0

    print("SWARM BOT navigation started. Press 'q' to quit.")

    while True:
        ok, frame = cap.read()
        if not ok:
            print("Camera read failed.")
            break

        markers = detect_markers(detector, frame)

        bot_info = None
        target_info = None

        if config.BOT_MARKER_ID in markers:
            corners = markers[config.BOT_MARKER_ID]
            bot_info = {
                "center": marker_center(corners),
                "heading": marker_heading_deg(corners),
            }
            draw_marker_info(frame, corners, config.BOT_MARKER_ID, color=(0, 255, 0))
            bot_missing_frames = 0
        else:
            bot_missing_frames += 1

        if config.TARGET_MARKER_ID in markers:
            corners = markers[config.TARGET_MARKER_ID]
            target_info = {
                "center": marker_center(corners),
                "size": marker_size(corners),
            }
            draw_marker_info(frame, corners, config.TARGET_MARKER_ID, color=(255, 0, 0))
            target_missing_frames = 0
        else:
            target_missing_frames += 1

        # ---------------- Decision logic ----------------
        angle_error = 0.0
        command = "stop"
        status = "NAVIGATING"

        if bot_missing_frames >= config.MAX_MISSING_FRAMES:
            command = "stop"
            status = "BOT NOT FOUND"
        elif target_missing_frames >= config.MAX_MISSING_FRAMES:
            command = "stop"
            status = "TARGET NOT FOUND"
        elif bot_info and target_info:
            target_angle = target_direction_deg(bot_info["center"], target_info["center"])
            angle_error = compute_angle_error(bot_info["heading"], target_angle)
            command = decide_command(angle_error, target_info["size"])
            status = "TARGET REACHED" if command == "stop" else "NAVIGATING"
        else:
            # One of the markers missing but not yet past the missing-frame threshold
            command = "stop"
            status = "WAITING FOR MARKERS"

        link.send(command, force=(command == "stop"))

        draw_ui(frame, bot_info, target_info, angle_error, command, status)
        cv2.imshow("SWARM BOT - ArUco Navigation", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            link.send("stop", force=True)
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
